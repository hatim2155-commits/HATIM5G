package com.hatim.fiveg.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** One row per Signal Monitor sample. Nullable columns = "not available". */
@Entity(tableName = "signal_logs")
data class SignalLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profileId: String,
    val timestampMillis: Long,
    val lteBand: String?,
    val nrBand: String?,
    val rsrp: Int?,
    val rsrq: Int?,
    val sinr: Int?,
    val cqi: Int?,
    val pci: Int?,
    val earfcn: Int?,
    val nrarfcn: Int?,
    val bandwidthMhz: Double?,
    val downloadMbps: Double?,
    val uploadMbps: Double?,
    val pingMs: Int?
)
