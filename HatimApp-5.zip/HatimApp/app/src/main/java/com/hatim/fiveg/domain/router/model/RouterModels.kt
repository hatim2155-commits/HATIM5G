package com.hatim.fiveg.domain.router.model

/**
 * Every field the router adapters expose is wrapped in [Metric] instead of a
 * raw nullable type. This is a deliberate rule from the project spec:
 *
 *   "If a value is unavailable, show 'Not available' — never invent one."
 *
 * [Metric.Unknown] is the ONLY representation for missing/unsupported data.
 * No adapter is allowed to fabricate a placeholder number.
 */
sealed class Metric<out T> {
    data class Value<T>(val value: T) : Metric<T>()
    data object Unknown : Metric<Nothing>()

    fun orNull(): T? = (this as? Value)?.value
}

enum class NetworkType { LTE, NR_NSA, NR_SA, UNKNOWN }

enum class ConnectionState { CONNECTED, CONNECTING, DISCONNECTED, ERROR }

data class RouterInfo(
    val manufacturer: Metric<String>,
    val model: Metric<String>,
    val firmwareVersion: Metric<String>,
    val hardwareVersion: Metric<String>,
    val imei: Metric<String>,
    val serialNumber: Metric<String>,
    val routerIp: Metric<String>,
    val macAddress: Metric<String>,
    val uptimeSeconds: Metric<Long>,
    val simStatus: Metric<String>,
    val networkOperator: Metric<String>
)

data class NetworkStatus(
    val connectionState: ConnectionState,
    val networkType: NetworkType,
    val operatorName: Metric<String>,
    val connectionDurationSeconds: Metric<Long>,
    val routerIp: Metric<String>,
    val pingMs: Metric<Int>,
    val downloadMbps: Metric<Double>,
    val uploadMbps: Metric<Double>
)

data class LteInfo(
    val band: Metric<String>,
    val pci: Metric<Int>,
    val earfcn: Metric<Int>,
    val dlEarfcn: Metric<Int>,
    val ulEarfcn: Metric<Int>,
    val bandwidthMhz: Metric<Double>,
    val rsrp: Metric<Int>,
    val rsrq: Metric<Int>,
    val sinr: Metric<Int>,
    val rssi: Metric<Int>,
    val cqi: Metric<Int>,
    val cellId: Metric<String>,
    val enbId: Metric<String>,
    val carrierAggregation: Metric<String>
)

data class NrInfo(
    val band: Metric<String>,
    val pci: Metric<Int>,
    val nrarfcn: Metric<Int>,
    val bandwidthMhz: Metric<Double>,
    val rsrp: Metric<Int>,
    val rsrq: Metric<Int>,
    val sinr: Metric<Int>,
    val ssb: Metric<Int>,
    val cellId: Metric<String>,
    val mode: NetworkType,
    val carrierAggregation: Metric<String>,
    val enDc: Metric<Boolean>
)

/** One physical LTE or NR carrier component inside a CA combination. */
data class CarrierComponent(
    val band: String,
    val bandwidthMhz: Double,
    val isPrimary: Boolean
)

data class CaInfo(
    val lteComponents: List<CarrierComponent>,
    val nrComponents: List<CarrierComponent>,
    val lteCaLabel: Metric<String>,   // e.g. "3CA"
    val nrCaLabel: Metric<String>,    // e.g. "2CC"
    val totalLteBandwidthMhz: Metric<Double>,
    val totalNrBandwidthMhz: Metric<Double>,
    val totalAggregatedBandwidthMhz: Metric<Double>
)

data class SignalInfo(
    val rsrp: Metric<Int>,
    val rsrq: Metric<Int>,
    val sinr: Metric<Int>,
    val rssi: Metric<Int>,
    val cqi: Metric<Int>
)

data class CellInfo(
    val cellId: Metric<String>,
    val pci: Metric<Int>,
    val trackingAreaCode: Metric<String>
)

data class FirmwareInfo(
    val currentVersion: Metric<String>,
    val hardwareVersion: Metric<String>,
    val configVersion: Metric<String>,
    val updateAvailable: Metric<Boolean>
)
