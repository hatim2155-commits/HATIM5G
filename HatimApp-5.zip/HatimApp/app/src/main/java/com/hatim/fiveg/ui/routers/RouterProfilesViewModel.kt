package com.hatim.fiveg.ui.routers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hatim.fiveg.data.local.db.entity.RouterProfileEntity
import com.hatim.fiveg.data.repository.RouterRepository
import com.hatim.fiveg.domain.router.Manufacturer
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RouterProfilesViewModel(
    private val routerRepository: RouterRepository
) : ViewModel() {

    val profiles: StateFlow<List<RouterProfileEntity>> =
        routerRepository.observeProfiles().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addOrUpdateProfile(
        id: String?,
        displayName: String,
        manufacturer: Manufacturer,
        routerIp: String,
        username: String,
        password: String
    ) {
        viewModelScope.launch {
            val profile = RouterProfileEntity(
                id = id ?: java.util.UUID.randomUUID().toString(),
                displayName = displayName,
                manufacturerKey = manufacturer.key,
                routerIp = routerIp
            )
            routerRepository.saveProfile(profile, username, password)
        }
    }

    fun deleteProfile(profile: RouterProfileEntity) {
        viewModelScope.launch { routerRepository.deleteProfile(profile) }
    }

    fun setDefault(profile: RouterProfileEntity) {
        viewModelScope.launch { routerRepository.setDefaultProfile(profile.id) }
    }
}
