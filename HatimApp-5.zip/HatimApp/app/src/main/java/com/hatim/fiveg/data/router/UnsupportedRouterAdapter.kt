package com.hatim.fiveg.data.router

import com.hatim.fiveg.domain.router.*
import com.hatim.fiveg.domain.router.model.*

/**
 * Used for manufacturers/models that don't have a real adapter yet.
 * Every call fails explicitly with UNSUPPORTED_MODEL — per spec this must
 * surface as "هذا الموديل غير مدعوم حاليًا" in the UI, never fabricated data.
 */
class UnsupportedRouterAdapter(override val manufacturerKey: String = "unknown") : RouterAdapter {

    private fun <T> unsupported(): AdapterResult<T> =
        AdapterResult.Failure(
            AdapterFailureReason.UNSUPPORTED_MODEL,
            "هذا الموديل غير مدعوم حاليًا"
        )

    override suspend fun login(config: RouterConnectionConfig) = unsupported<Unit>()
    override suspend fun getRouterInfo(config: RouterConnectionConfig) = unsupported<RouterInfo>()
    override suspend fun getNetworkStatus(config: RouterConnectionConfig) = unsupported<NetworkStatus>()
    override suspend fun getLTEInfo(config: RouterConnectionConfig) = unsupported<LteInfo>()
    override suspend fun getNRInfo(config: RouterConnectionConfig) = unsupported<NrInfo>()
    override suspend fun getCAInfo(config: RouterConnectionConfig) = unsupported<CaInfo>()
    override suspend fun getSignalInfo(config: RouterConnectionConfig) = unsupported<SignalInfo>()
    override suspend fun getCellInfo(config: RouterConnectionConfig) = unsupported<CellInfo>()
    override suspend fun getFirmwareInfo(config: RouterConnectionConfig) = unsupported<FirmwareInfo>()
    override suspend fun supportsBandLock(config: RouterConnectionConfig) = false
}
