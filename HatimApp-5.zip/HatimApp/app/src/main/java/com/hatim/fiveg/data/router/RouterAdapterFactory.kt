package com.hatim.fiveg.data.router

import com.hatim.fiveg.data.debug.DebugLogStore
import com.hatim.fiveg.data.router.huawei.HuaweiAdapter
import com.hatim.fiveg.data.router.zte.ZteAdapter
import com.hatim.fiveg.domain.router.Manufacturer
import com.hatim.fiveg.domain.router.RouterAdapter

/**
 * Single place that maps a [Manufacturer] to its [RouterAdapter]
 * implementation. Adding a new manufacturer means adding one line here plus
 * a new Adapter class — nothing else in the app needs to change, since the
 * rest of the codebase only ever talks to the RouterAdapter interface.
 */
class RouterAdapterFactory(private val debugLogStore: DebugLogStore) {

    fun create(manufacturer: Manufacturer): RouterAdapter = when (manufacturer) {
        Manufacturer.HUAWEI -> HuaweiAdapter(debugLogStore)
        Manufacturer.ZTE -> ZteAdapter()
        // TP-Link, Nokia, Zyxel, D-Link: not implemented yet.
        // Each will get its own adapter class following the same pattern
        // as Huawei/ZTE once we have documented API/firmware details.
        else -> UnsupportedRouterAdapter(manufacturer.key)
    }
}
