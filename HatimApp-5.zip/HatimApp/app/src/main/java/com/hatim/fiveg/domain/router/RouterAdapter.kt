package com.hatim.fiveg.domain.router

import com.hatim.fiveg.domain.router.model.*

/**
 * Credentials + connection target the user configured in Router Profiles.
 * Never logged, never sent anywhere except directly to [routerIp] on the LAN.
 */
data class RouterConnectionConfig(
    val routerIp: String,
    val username: String,
    val password: String
)

sealed class AdapterResult<out T> {
    data class Success<T>(val data: T) : AdapterResult<T>()
    data class Failure(val reason: AdapterFailureReason, val message: String? = null) : AdapterResult<Nothing>()
}

enum class AdapterFailureReason {
    UNREACHABLE,           // router not responding on the LAN
    AUTH_FAILED,           // wrong username/password
    UNSUPPORTED_MODEL,     // this specific model/firmware isn't implemented yet
    PARSE_ERROR,           // response received but couldn't be understood
    TIMEOUT
}

/**
 * Common contract every manufacturer-specific adapter must implement.
 *
 * IMPORTANT project rule: an adapter must NEVER invent data. Any field it
 * cannot read from the router is returned as [Metric.Unknown] — never a
 * guessed or hardcoded value. If the model/firmware itself isn't supported,
 * return [AdapterResult.Failure] with [AdapterFailureReason.UNSUPPORTED_MODEL]
 * instead of returning partially-fabricated data.
 *
 * Implementations must only use the credentials the user entered. No
 * authentication bypass, no exploitation of firmware vulnerabilities.
 */
interface RouterAdapter {

    /** Manufacturer key this adapter handles, e.g. "huawei", "zte". */
    val manufacturerKey: String

    /** Attempts to authenticate against the router using [config]. */
    suspend fun login(config: RouterConnectionConfig): AdapterResult<Unit>

    suspend fun getRouterInfo(config: RouterConnectionConfig): AdapterResult<RouterInfo>

    suspend fun getNetworkStatus(config: RouterConnectionConfig): AdapterResult<NetworkStatus>

    suspend fun getLTEInfo(config: RouterConnectionConfig): AdapterResult<LteInfo>

    suspend fun getNRInfo(config: RouterConnectionConfig): AdapterResult<NrInfo>

    suspend fun getCAInfo(config: RouterConnectionConfig): AdapterResult<CaInfo>

    suspend fun getSignalInfo(config: RouterConnectionConfig): AdapterResult<SignalInfo>

    suspend fun getCellInfo(config: RouterConnectionConfig): AdapterResult<CellInfo>

    suspend fun getFirmwareInfo(config: RouterConnectionConfig): AdapterResult<FirmwareInfo>

    /**
     * True only if this adapter has a confirmed, documented way to lock bands
     * on the connected model. Band Lock UI must hide/disable itself when this
     * is false rather than attempting an unsupported action.
     */
    suspend fun supportsBandLock(config: RouterConnectionConfig): Boolean
}
