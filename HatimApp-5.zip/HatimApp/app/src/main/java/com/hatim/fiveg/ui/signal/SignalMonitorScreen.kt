package com.hatim.fiveg.ui.signal

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hatim.fiveg.data.repository.RouterRepository

/**
 * §16 Signal Monitor. UI shell for interval-based recording; the actual
 * polling/graphing wiring (Vico charts + Room inserts) is the next
 * implementation step once a real adapter can return live SignalInfo.
 */
@Composable
fun SignalMonitorScreen(routerRepository: RouterRepository) {
    var isRecording by remember { mutableStateOf(false) }
    var intervalSeconds by remember { mutableIntStateOf(5) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Signal Monitor", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(16.dp))

        Text("الفاصل الزمني للتسجيل")
        SingleChoiceIntervalRow(
            options = listOf(1, 5, 10, 30),
            selected = intervalSeconds,
            onSelect = { intervalSeconds = it }
        )

        Spacer(Modifier.height(16.dp))
        Button(onClick = { isRecording = !isRecording }) {
            Text(if (isRecording) "إيقاف التسجيل" else "بدء التسجيل")
        }

        Spacer(Modifier.height(24.dp))
        if (isRecording) {
            Text("جارٍ التسجيل كل $intervalSeconds ثانية...")
            LinearProgressIndicator(Modifier.fillMaxWidth())
        } else {
            Text("لا يوجد تسجيل نشط. الرسوم البيانية لـ SINR/RSRP/Speed/Bandwidth ستظهر هنا أثناء التسجيل.")
        }
    }
}

@Composable
private fun SingleChoiceIntervalRow(
    options: List<Int>,
    selected: Int,
    onSelect: (Int) -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { option ->
            FilterChip(
                selected = option == selected,
                onClick = { onSelect(option) },
                label = { Text("${option}s") }
            )
        }
    }
}
