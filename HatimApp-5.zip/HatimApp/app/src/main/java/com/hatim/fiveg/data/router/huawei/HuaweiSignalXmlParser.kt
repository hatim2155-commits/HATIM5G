package com.hatim.fiveg.data.router.huawei

import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.StringReader

/**
 * Raw (still-stringly-typed) fields exactly as returned by the router's
 * `api/device/signal` endpoint. Confirmed against a real device response:
 *
 * <response>
 *   <pci>3</pci>
 *   <cell_id>0749965-006</cell_id>
 *   <rsrq>-5.5dB</rsrq>
 *   <rsrp>-68dBm</rsrp>
 *   <rssi>-42dBm</rssi>
 *   <sinr>15dB</sinr>
 *   <mode>7</mode>
 *   <ulbandwidth>20MHz</ulbandwidth>
 *   <dlbandwidth>20MHz</dlbandwidth>
 *   <earfcn>DL:500 UL:18500</earfcn>
 *   <tac>9017</tac>
 *   <band>20MHz@500(B1) + 100MHz@640776(N78)</band>
 *   <bandInfo>B1</bandInfo>
 *   <plmn>42001</plmn>
 *   <enodeb_id>0749965</enodeb_id>
 *   <cqi0>15</cqi0>
 *   <nrulbandwidth>100MHz</nrulbandwidth>
 *   <nrdlbandwidth>100MHz</nrdlbandwidth>
 *   <nrearfcn>640776</nrearfcn>
 *   <nrsinr>19dB</nrsinr>
 *   <nrrsrp>-88dBm</nrrsrp>
 *   <nrrsrq>-10.0dB</nrrsrq>
 *   <nrcqi0>15</nrcqi0>
 *   <scc_pci>505</scc_pci>
 *   ...
 * </response>
 *
 * Every field is nullable: an empty/self-closing tag (e.g. <rac/>) or a
 * missing tag both map to null here, and stay null all the way up to
 * Metric.Unknown — never a fabricated value.
 */
data class HuaweiRawSignal(
    val pci: String? = null,
    val cellId: String? = null,
    val rsrq: String? = null,
    val rsrp: String? = null,
    val rssi: String? = null,
    val sinr: String? = null,
    val mode: String? = null,
    val ulBandwidth: String? = null,
    val dlBandwidth: String? = null,
    val earfcn: String? = null,
    val tac: String? = null,
    val band: String? = null,
    val bandInfo: String? = null,
    val plmn: String? = null,
    val enodebId: String? = null,
    val cqi0: String? = null,
    val nrUlBandwidth: String? = null,
    val nrDlBandwidth: String? = null,
    val nrEarfcn: String? = null,
    val nrSinr: String? = null,
    val nrRsrp: String? = null,
    val nrRsrq: String? = null,
    val nrCqi0: String? = null,
    val sccPci: String? = null
)

object HuaweiSignalXmlParser {

    private val knownTags = setOf(
        "pci", "cell_id", "rsrq", "rsrp", "rssi", "sinr", "mode",
        "ulbandwidth", "dlbandwidth", "earfcn", "tac", "band", "bandInfo",
        "plmn", "enodeb_id", "cqi0", "nrulbandwidth", "nrdlbandwidth",
        "nrearfcn", "nrsinr", "nrrsrp", "nrrsrq", "nrcqi0", "scc_pci"
    )

    /** Returns null (not a fabricated default) if the XML can't be parsed at all. */
    fun parse(xml: String): HuaweiRawSignal? {
        return try {
            val values = mutableMapOf<String, String>()
            val factory = XmlPullParserFactory.newInstance()
            val parser = factory.newPullParser()
            parser.setInput(StringReader(xml))

            var currentTag: String? = null
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> currentTag = parser.name
                    XmlPullParser.TEXT -> {
                        val tag = currentTag
                        if (tag != null && tag in knownTags) {
                            val text = parser.text?.trim()
                            if (!text.isNullOrEmpty()) values[tag] = text
                        }
                    }
                    XmlPullParser.END_TAG -> currentTag = null
                }
                event = parser.next()
            }

            HuaweiRawSignal(
                pci = values["pci"],
                cellId = values["cell_id"],
                rsrq = values["rsrq"],
                rsrp = values["rsrp"],
                rssi = values["rssi"],
                sinr = values["sinr"],
                mode = values["mode"],
                ulBandwidth = values["ulbandwidth"],
                dlBandwidth = values["dlbandwidth"],
                earfcn = values["earfcn"],
                tac = values["tac"],
                band = values["band"],
                bandInfo = values["bandInfo"],
                plmn = values["plmn"],
                enodebId = values["enodeb_id"],
                cqi0 = values["cqi0"],
                nrUlBandwidth = values["nrulbandwidth"],
                nrDlBandwidth = values["nrdlbandwidth"],
                nrEarfcn = values["nrearfcn"],
                nrSinr = values["nrsinr"],
                nrRsrp = values["nrrsrp"],
                nrRsrq = values["nrrsrq"],
                nrCqi0 = values["nrcqi0"],
                sccPci = values["scc_pci"]
            )
        } catch (t: Throwable) {
            null
        }
    }

    // ---- small unit-stripping helpers; return null (not 0) on failure ----

    fun stripDbm(raw: String?): Int? = raw?.replace("dBm", "", ignoreCase = true)?.trim()?.toIntOrNull()

    fun stripDb(raw: String?): Int? = raw?.replace("dB", "", ignoreCase = true)?.trim()?.let {
        // handles values like "-5.5" that are actually integers-ish for our model;
        // RSRQ/SINR can be fractional on some firmwares, so round rather than drop.
        it.toDoubleOrNull()?.let { d -> Math.round(d).toInt() }
    }

    fun stripMhz(raw: String?): Double? = raw?.replace("MHz", "", ignoreCase = true)?.trim()?.toDoubleOrNull()

    /** "DL:500 UL:18500" -> Pair(500, 18500) */
    fun parseDlUlEarfcn(raw: String?): Pair<Int?, Int?> {
        if (raw == null) return null to null
        val dl = Regex("DL:(\\d+)").find(raw)?.groupValues?.get(1)?.toIntOrNull()
        val ul = Regex("UL:(\\d+)").find(raw)?.groupValues?.get(1)?.toIntOrNull()
        return dl to ul
    }

    /**
     * "20MHz@500(B1) + 100MHz@640776(N78)" -> list of (bandwidthMhz, arfcn, bandLabel)
     * Order in the string is preserved; the first component is treated as primary.
     */
    fun parseBandCombination(raw: String?): List<BandComponentRaw> {
        if (raw.isNullOrBlank()) return emptyList()
        val regex = Regex("([0-9.]+)MHz@(\\d+)\\(([A-Za-z0-9]+)\\)")
        return regex.findAll(raw).map { match ->
            BandComponentRaw(
                bandwidthMhz = match.groupValues[1].toDoubleOrNull(),
                arfcn = match.groupValues[2].toIntOrNull(),
                bandLabel = match.groupValues[3]
            )
        }.toList()
    }
}

data class BandComponentRaw(
    val bandwidthMhz: Double?,
    val arfcn: Int?,
    val bandLabel: String
)
