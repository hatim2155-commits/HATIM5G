package com.hatim.fiveg.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hatim.fiveg.data.repository.RouterRepository

/** §28 Settings shell. Persistence via DataStore is a follow-up step. */
@Composable
fun SettingsScreen(routerRepository: RouterRepository, onOpenDebug: () -> Unit) {
    var darkMode by remember { mutableStateOf("Dark") }
    var interval by remember { mutableIntStateOf(5) }
    var speedUnit by remember { mutableStateOf("Mbps") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(16.dp))

        Text("الوضع")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Dark", "Light", "System").forEach {
                FilterChip(selected = darkMode == it, onClick = { darkMode = it }, label = { Text(it) })
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("الفاصل الزمني لتحديث البيانات")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1, 5, 10, 30).forEach {
                FilterChip(selected = interval == it, onClick = { interval = it }, label = { Text("${it}s") })
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("وحدة السرعة")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Mbps", "MB/s").forEach {
                FilterChip(selected = speedUnit == it, onClick = { speedUnit = it }, label = { Text(it) })
            }
        }

        Spacer(Modifier.height(24.dp))
        Text(
            "إدارة الراوترات وكلمات المرور متاحة من تبويب \"الراوترات\".",
            style = MaterialTheme.typography.labelSmall
        )

        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onOpenDebug) {
            Text("وضع Debug (سجل اكتشاف API)")
        }
    }
}
