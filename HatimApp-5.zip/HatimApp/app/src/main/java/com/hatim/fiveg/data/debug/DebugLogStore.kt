package com.hatim.fiveg.data.debug

import com.hatim.fiveg.domain.debug.DebugLogEntry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicLong

/**
 * Process-memory-only log of API discovery/read attempts. Never persisted
 * to disk, never sent anywhere — purely for the in-app Debug screen.
 * Capped so a long session doesn't grow this unbounded.
 */
class DebugLogStore(private val maxEntries: Int = 200) {

    private val idGenerator = AtomicLong(0)
    private val _entries = MutableStateFlow<List<DebugLogEntry>>(emptyList())
    val entries: StateFlow<List<DebugLogEntry>> = _entries.asStateFlow()

    fun log(
        manufacturerKey: String,
        endpointPath: String,
        httpStatus: Int?,
        responseTimeMs: Long,
        outcome: com.hatim.fiveg.domain.debug.DebugOutcome,
        note: String? = null
    ) {
        val entry = DebugLogEntry(
            id = idGenerator.incrementAndGet(),
            timestampMillis = System.currentTimeMillis(),
            manufacturerKey = manufacturerKey,
            endpointPath = endpointPath,
            httpStatus = httpStatus,
            responseTimeMs = responseTimeMs,
            outcome = outcome,
            note = note
        )
        _entries.value = (listOf(entry) + _entries.value).take(maxEntries)
    }

    fun clear() {
        _entries.value = emptyList()
    }
}
