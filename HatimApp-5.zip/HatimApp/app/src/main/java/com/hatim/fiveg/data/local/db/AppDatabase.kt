package com.hatim.fiveg.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.hatim.fiveg.data.local.db.dao.BandTestDao
import com.hatim.fiveg.data.local.db.dao.RouterProfileDao
import com.hatim.fiveg.data.local.db.dao.SignalLogDao
import com.hatim.fiveg.data.local.db.dao.SpeedTestDao
import com.hatim.fiveg.data.local.db.entity.BandTestEntity
import com.hatim.fiveg.data.local.db.entity.RouterProfileEntity
import com.hatim.fiveg.data.local.db.entity.SignalLogEntity
import com.hatim.fiveg.data.local.db.entity.SpeedTestEntity

@Database(
    entities = [
        RouterProfileEntity::class,
        SignalLogEntity::class,
        SpeedTestEntity::class,
        BandTestEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun routerProfileDao(): RouterProfileDao
    abstract fun signalLogDao(): SignalLogDao
    abstract fun speedTestDao(): SpeedTestDao
    abstract fun bandTestDao(): BandTestDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "hatim.db")
                .build()
    }
}
