package com.hatim.fiveg.data.router.zte

import com.hatim.fiveg.domain.router.*
import com.hatim.fiveg.domain.router.model.*
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Adapter for ZTE MF/MC-series routers.
 *
 * STATUS: skeleton. ZTE's goform-based interface (e.g. goform/goform_get_cmd_process)
 * varies enough between families (MF9x, MC888, MC8020, etc.) that this class
 * is intentionally left unimplemented rather than guessing a shared shape.
 *
 * Per the architecture in RouterAdapter, if a specific ZTE family needs its
 * own quirks, add a sibling class (e.g. ZteMc888Adapter) and select it in
 * RouterAdapterFactory using detected model info — do not overload this one
 * class with undocumented special cases.
 */
class ZteAdapter(
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()
) : RouterAdapter {

    override val manufacturerKey: String = "zte"

    override suspend fun login(config: RouterConnectionConfig): AdapterResult<Unit> =
        AdapterResult.Failure(
            AdapterFailureReason.UNSUPPORTED_MODEL,
            "دعم هذا الموديل من ZTE قيد التطوير"
        )

    override suspend fun getRouterInfo(config: RouterConnectionConfig): AdapterResult<RouterInfo> =
        AdapterResult.Failure(AdapterFailureReason.UNSUPPORTED_MODEL)

    override suspend fun getNetworkStatus(config: RouterConnectionConfig): AdapterResult<NetworkStatus> =
        AdapterResult.Failure(AdapterFailureReason.UNSUPPORTED_MODEL)

    override suspend fun getLTEInfo(config: RouterConnectionConfig): AdapterResult<LteInfo> =
        AdapterResult.Failure(AdapterFailureReason.UNSUPPORTED_MODEL)

    override suspend fun getNRInfo(config: RouterConnectionConfig): AdapterResult<NrInfo> =
        AdapterResult.Failure(AdapterFailureReason.UNSUPPORTED_MODEL)

    override suspend fun getCAInfo(config: RouterConnectionConfig): AdapterResult<CaInfo> =
        AdapterResult.Failure(AdapterFailureReason.UNSUPPORTED_MODEL)

    override suspend fun getSignalInfo(config: RouterConnectionConfig): AdapterResult<SignalInfo> =
        AdapterResult.Failure(AdapterFailureReason.UNSUPPORTED_MODEL)

    override suspend fun getCellInfo(config: RouterConnectionConfig): AdapterResult<CellInfo> =
        AdapterResult.Failure(AdapterFailureReason.UNSUPPORTED_MODEL)

    override suspend fun getFirmwareInfo(config: RouterConnectionConfig): AdapterResult<FirmwareInfo> =
        AdapterResult.Failure(AdapterFailureReason.UNSUPPORTED_MODEL)

    override suspend fun supportsBandLock(config: RouterConnectionConfig): Boolean = false
}
