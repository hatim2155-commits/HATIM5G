package com.hatim.fiveg.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hatim.fiveg.data.repository.RouterRepository
import com.hatim.fiveg.domain.router.AdapterResult
import com.hatim.fiveg.domain.router.model.LteInfo
import com.hatim.fiveg.domain.router.model.NetworkStatus
import com.hatim.fiveg.domain.router.model.NrInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class DashboardUiState(
    val isLoading: Boolean = false,
    val statusMessage: String? = null,
    val networkStatus: NetworkStatus? = null,
    val lteInfo: LteInfo? = null,
    val nrInfo: NrInfo? = null
)

class DashboardViewModel(
    private val routerRepository: RouterRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    /**
     * Reads the default (or first saved) profile and refreshes from it.
     * Does NOT take a profile id — that was previously hardcoded to the
     * literal string "default", which never matched a real profile's UUID
     * and made the Dashboard always show "no router saved" even when one
     * existed. Resolving the id here, from the database, fixes that.
     */
    fun refresh() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, statusMessage = null)

            val profileId = routerRepository.resolveDefaultProfileId()
            if (profileId == null) {
                _uiState.value = DashboardUiState(
                    isLoading = false,
                    statusMessage = "لم يتم العثور على راوتر محفوظ. أضف راوترًا من صفحة الراوترات."
                )
                return@launch
            }

            val resolved = routerRepository.resolveAdapter(profileId)
            if (resolved == null) {
                _uiState.value = DashboardUiState(
                    isLoading = false,
                    statusMessage = "لم يتم العثور على راوتر محفوظ. أضف راوترًا من صفحة الراوترات."
                )
                return@launch
            }
            val (adapter, config) = resolved

            val statusResult = adapter.getNetworkStatus(config)
            val lteResult = adapter.getLTEInfo(config)
            val nrResult = adapter.getNRInfo(config)

            _uiState.value = DashboardUiState(
                isLoading = false,
                statusMessage = (statusResult as? AdapterResult.Failure)?.message
                    ?: (statusResult as? AdapterResult.Failure)?.reason?.name,
                networkStatus = (statusResult as? AdapterResult.Success)?.data,
                lteInfo = (lteResult as? AdapterResult.Success)?.data,
                nrInfo = (nrResult as? AdapterResult.Success)?.data
            )
        }
    }
}
