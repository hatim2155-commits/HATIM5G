package com.hatim.fiveg.navigation

sealed class NavDestination(val route: String, val labelAr: String, val icon: String) {
    data object Dashboard : NavDestination("dashboard", "الرئيسية", "📊")
    data object CaAnalyzer : NavDestination("ca_analyzer", "CA", "🔗")
    data object SignalMonitor : NavDestination("signal_monitor", "الإشارة", "📶")
    data object BandTester : NavDestination("band_tester", "الترددات", "📶")
    data object Routers : NavDestination("routers", "الراوترات", "📡")
    data object Diagnostics : NavDestination("diagnostics", "التشخيص", "🛠")
    data object Settings : NavDestination("settings", "الإعدادات", "⚙")

    companion object {
        val bottomBarItems = listOf(
            Dashboard, CaAnalyzer, SignalMonitor, BandTester, Routers, Diagnostics, Settings
        )
    }
}
