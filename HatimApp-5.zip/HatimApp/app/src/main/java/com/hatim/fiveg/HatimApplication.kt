package com.hatim.fiveg

import android.app.Application
import com.hatim.fiveg.data.debug.DebugLogStore
import com.hatim.fiveg.data.local.db.AppDatabase
import com.hatim.fiveg.data.security.SecureCredentialsStore
import com.hatim.fiveg.data.router.RouterAdapterFactory
import com.hatim.fiveg.data.repository.RouterRepository

/**
 * Application-wide manual "DI container".
 *
 * The project intentionally avoids a DI framework at this early stage so the
 * dependency graph stays easy to read while the Router Abstraction Layer is
 * still being built out. It can be swapped for Hilt later without touching
 * the domain/UI layers, since everything below depends on interfaces only.
 */
class HatimApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var credentialsStore: SecureCredentialsStore
        private set

    lateinit var debugLogStore: DebugLogStore
        private set

    lateinit var routerRepository: RouterRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.build(this)
        credentialsStore = SecureCredentialsStore(this)
        debugLogStore = DebugLogStore()
        routerRepository = RouterRepository(
            database = database,
            credentialsStore = credentialsStore,
            adapterFactory = RouterAdapterFactory(debugLogStore)
        )
    }
}
