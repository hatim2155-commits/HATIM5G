package com.hatim.fiveg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.hatim.fiveg.navigation.HatimNavGraph
import com.hatim.fiveg.ui.theme.HatimTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as HatimApplication

        setContent {
            HatimTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HatimNavGraph(
                        routerRepository = app.routerRepository,
                        debugLogStore = app.debugLogStore
                    )
                }
            }
        }
    }
}
